package com.novalux.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.TextWatcher;
import android.text.Editable;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, appList;
    EditText search;
    ArrayList<ResolveInfo> apps = new ArrayList<>();
    int violet = Color.rgb(174, 111, 255);
    int dp(float x) { return (int)(x * getResources().getDisplayMetrics().density); }
    GradientDrawable bg(int color, int radius) { GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d; }
    TextView text(String s, int size, int color) { TextView t=new TextView(this);t.setText(s);t.setTextColor(color);t.setTextSize(size);return t; }
    void pad(View v,int a,int b,int c,int d){v.setPadding(dp(a),dp(b),dp(c),dp(d));}
    @Override public void onCreate(Bundle b){super.onCreate(b);showHome();}
    void showHome(){
        GradientDrawable gradient = new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff090b18,0xff25123c,0xff090b18});
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackground(gradient);pad(root,24,38,24,18);setContentView(root);
        TextView brand=text("✦  N O V A   L U X",16,violet);brand.setTypeface(null,Typeface.BOLD);root.addView(brand);
        TextView date=text(new SimpleDateFormat("EEEE, d MMMM",Locale.getDefault()).format(new Date()),15,0xffc5bbd5);pad(date,0,54,0,6);root.addView(date);
        TextView clock=text(new SimpleDateFormat("h:mm",Locale.getDefault()).format(new Date()),68,Color.WHITE);clock.setTypeface(Typeface.create("sans-serif-light",Typeface.NORMAL));root.addView(clock);
        TextView tagline=text("Your space. Your style.",16,0xffb7a3ce);root.addView(tagline);
        Space space=new Space(this);root.addView(space,new LinearLayout.LayoutParams(1,0,1));
        TextView button=text("⌕   Explore your apps     →",19,Color.WHITE);button.setGravity(Gravity.CENTER_VERTICAL);pad(button,20,20,16,20);button.setBackground(bg(0xff392450,22));root.addView(button);button.setOnClickListener(v->showDrawer());
        TextView footer=text("NOVA LUX  •  PREMIUM LAUNCHER",11,0xff9b88ad);footer.setGravity(Gravity.CENTER);pad(footer,0,26,0,4);root.addView(footer);
    }
    void showDrawer(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xff0d0d19);pad(root,20,26,20,10);setContentView(root);
        TextView back=text("←   All apps",26,Color.WHITE);back.setTypeface(null,Typeface.BOLD);pad(back,0,8,0,20);root.addView(back);back.setOnClickListener(v->showHome());
        search=new EditText(this);search.setSingleLine(true);search.setTextColor(Color.WHITE);search.setHintTextColor(0xff9d90b0);search.setHint("Search installed apps");pad(search,16,10,16,10);search.setBackground(bg(0xff282038,16));root.addView(search);
        ScrollView scroll=new ScrollView(this);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));appList=new LinearLayout(this);appList.setOrientation(LinearLayout.VERTICAL);scroll.addView(appList);
        Intent intent=new Intent(Intent.ACTION_MAIN,null);intent.addCategory(Intent.CATEGORY_LAUNCHER);
        apps=new ArrayList<>(getPackageManager().queryIntentActivities(intent,0));
        Collections.sort(apps,(a,b)->a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()));
        populate("");
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){populate(s.toString());}public void afterTextChanged(Editable e){} });
    }
    void populate(String q){
        appList.removeAllViews();
        for(ResolveInfo app:apps){String name=app.loadLabel(getPackageManager()).toString();if(!name.toLowerCase(Locale.ROOT).contains(q.toLowerCase(Locale.ROOT)))continue;
            LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.HORIZONTAL);item.setGravity(Gravity.CENTER_VERTICAL);pad(item,10,13,8,13);
            ImageView icon=new ImageView(this);icon.setImageDrawable(app.loadIcon(getPackageManager()));item.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(42)));
            TextView label=text(name,17,Color.WHITE);pad(label,18,0,0,0);item.addView(label);appList.addView(item);
            item.setOnClickListener(v->{try{Intent launch=new Intent(Intent.ACTION_MAIN);launch.addCategory(Intent.CATEGORY_LAUNCHER);launch.setClassName(app.activityInfo.packageName,app.activityInfo.name);launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(launch);}catch(Exception e){Toast.makeText(this,"Could not open app",Toast.LENGTH_SHORT).show();}});
        }
    }
    @Override public void onBackPressed(){showHome();}
}
