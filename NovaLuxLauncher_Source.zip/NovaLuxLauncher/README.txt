NOVA LUX — Native Android Launcher starter project

This is Android source code, NOT an APK.
Features: HOME intent support, dark purple premium home screen, local clock/date, searchable installed app drawer, tap-to-open apps.

Build using Android Gradle Plugin 8.7.3 and Android SDK 35 in an Android build environment. A computer is not necessarily required if using a suitable cloud build service, but a build process is required.

Important: This is an early functional prototype, not a complete commercial launcher. The clock refreshes when the home screen is shown; widgets, icon packs, wallpaper changes, gesture controls, and persistence are not implemented. Android device behavior varies; APK has not been built or tested here.
